﻿using UnityEngine;
using System.Collections;

public class ResetPowerUp : PowerUpBase {

	//reset the player's speed and end the speed power up. 
	public void EndPowerUpSpeed () {

		StartCoroutine ("StopSpeedPowerUp");
	}

	IEnumerator StopSpeedPowerUp ()

	{

		yield return new WaitForSeconds (5);

		playerSpeed = 4;

		Debug.Log ("Player's Speed is back to normal which is " + playerSpeed);

	}

	//Resets the player's jump and end the jump power up 

	public void EndPowerUpJump () {

		StartCoroutine ("StopJumpPowerUp");
	}

	IEnumerator StopJumpPowerUp ()

	{

		yield return new WaitForSeconds (20);

		playerJump = 5.0f;

		Debug.Log ("Player's Jump is back to normal which is " + playerJump);

	}


	//Resets the player's invisibility and end the invisibility power up. 

	public void EndPowerUpInvisibility () {

		StartCoroutine ("StopInvisibilityPowerUp");
	}

	IEnumerator StopInvisibilityPowerUp ()

	{

		yield return new WaitForSeconds (20);

		playerInvisability = false;

		Debug.Log ("Player's invisiability is turned off");

	}

}
